<script setup lang="ts">
import Users from '../components/Users.vue'
</script>

<template>
  <main>
    <Users />
  </main>
</template>
